# Bitbucket -> AKS Deployment Scaffold (Ingress Enabled)

This repository is scaffolded to deploy your model service to AKS from Bitbucket Pipelines using:
- `score.py` (model logic)
- `requirements.txt` (runtime dependencies)
- `model/lgb_cat_model_v8.pkl` (model artifact)

## Runtime shape
- API: FastAPI app in `scoring.py`
- Docker image serves:
  - `GET /health`
  - `POST /score`
- Scoring calls your existing `score.py` `init()` and `score(payload)` directly.

## Files
- `Dockerfile`
- `bitbucket-pipelines.yml`
- `k8s/deployment.yaml`
- `k8s/service.yaml`
- `k8s/ingress.yaml`
- `score.py`
- `scoring.py`
- `requirements.txt`

## Required Bitbucket repository variables
Set these in **Repository settings -> Pipelines -> Repository variables**.

### Azure auth
- `AZURE_CLIENT_ID`
- `AZURE_CLIENT_SECRET`
- `AZURE_TENANT_ID`
- `AZURE_SUBSCRIPTION_ID`

### Registry / AKS
- `ACR_NAME` (example: `myacrname`)
- `IMAGE_REPOSITORY` (example: `stock-scoring-api`)
- `AKS_RESOURCE_GROUP`
- `AKS_CLUSTER_NAME`
- `K8S_NAMESPACE` (example: `prod`)

### App / ingress
- `APP_NAME` (example: `stock-scoring`)
- `MODEL_PATH` (use `/app/model/lgb_cat_model_v8.pkl`)
- `INGRESS_CLASS_NAME` (example: `nginx`)
- `INGRESS_HOST` (example: `score.example.com`)
- `TLS_SECRET_NAME` (example: `score-example-com-tls`)

### Optional smoke test
- `SCORE_TEST_PAYLOAD` (JSON body for `POST /score`; if unset, score smoke test is skipped)

## One-time AKS prerequisites
If ingress controller is not installed in AKS yet, install NGINX ingress once:

```bash
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
helm repo update
helm upgrade --install ingress-nginx ingress-nginx/ingress-nginx \
  --namespace ingress-nginx --create-namespace
```

If you need automatic TLS, install cert-manager and configure an issuer, then create your TLS secret referenced by `TLS_SECRET_NAME`.

## Deployment flow
- Pull request: build image only (validation)
- Push to `main`:
  1. Login to Azure
  2. Build image and push to ACR
  3. Get AKS credentials
  4. Render manifests using env vars (`envsubst`)
  5. Apply deployment/service/ingress
  6. Wait for rollout
  7. Smoke test `/health` and optional `/score`

## Local quick test
```bash
docker build -t stock-model-api .
docker run --rm -p 8000:8000 stock-model-api
curl http://localhost:8000/health
```
