param(
    [Parameter(Mandatory = $true)]
    [string]$AppName,

    [ValidateSet("VERY_HIGH", "HIGH", "MEDIUM", "LOW", "VERY_LOW")]
    [string]$BusinessCriticality = "HIGH",

    [string]$BusinessUnitGuid,
    [string]$PolicyGuid,
    [string[]]$TeamGuids,

    [switch]$Submit
)

$ErrorActionPreference = "Stop"

$repoRoot = Split-Path -Parent $PSScriptRoot
$outputPath = Join-Path $repoRoot "veracode\profile.json"

$profile = @{
    profile = @{
        name = $AppName
        business_criticality = $BusinessCriticality
    }
}

if ($BusinessUnitGuid) {
    $profile.profile.business_unit = @{ guid = $BusinessUnitGuid }
}

if ($PolicyGuid) {
    $profile.profile.policies = @(@{ guid = $PolicyGuid })
}

if ($TeamGuids -and $TeamGuids.Count -gt 0) {
    $profile.profile.teams = @()
    foreach ($teamGuid in $TeamGuids) {
        $profile.profile.teams += @{ guid = $teamGuid }
    }
}

$json = $profile | ConvertTo-Json -Depth 10
Set-Content -Path $outputPath -Value $json -Encoding UTF8
Write-Host "Created payload: $outputPath"

if (-not $Submit) {
    Write-Host "Dry run only. Add -Submit to create the profile in Veracode."
    exit 0
}

$httpCmd = Get-Command http -ErrorAction SilentlyContinue
if (-not $httpCmd) {
    throw "HTTPie ('http') not found. Install HTTPie + veracode_hmac auth plugin, then rerun with -Submit."
}

Write-Host "Submitting profile to Veracode Applications REST API..."
& http --auth-type=veracode_hmac POST "https://api.veracode.com/appsec/v1/applications" "@$outputPath"
