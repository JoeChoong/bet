from typing import Any

from fastapi import FastAPI, HTTPException, Request

import score as legacy_score

app = FastAPI(title="Stock Model Scoring API", version="1.0.0")

startup_error: str | None = None


@app.on_event("startup")
def startup() -> None:
    global startup_error
    try:
        legacy_score.init()
        startup_error = None
    except Exception as exc:  # pragma: no cover
        startup_error = str(exc)


@app.get("/health")
def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "model_loaded": getattr(legacy_score, "model", None) is not None,
        "startup_error": startup_error,
    }


@app.post("/score")
async def score(request: Request) -> dict[str, Any]:
    if getattr(legacy_score, "model", None) is None:
        raise HTTPException(status_code=503, detail=f"Model not loaded. Error: {startup_error}")

    try:
        payload = await request.json()
        predictions = legacy_score.score(payload)
        return {"predictions": predictions}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Scoring failed: {exc}") from exc
